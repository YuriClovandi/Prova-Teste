// Testes para a funcionalidade de Produtos
describe('Funcionalidade de Produtos do Sauce Demo', () => {

    // Antes de cada teste, faz o login para acessar a página de produtos
    beforeEach(() => {
      cy.visit('https://www.saucedemo.com/')
      cy.get('#user-name').type('standard_user');
      cy.get('#password').type('secret_sauce');
      cy.get('#login-button').click();
      cy.url().should('include', '/inventory.html');
    });
  
    // Teste para verificar a exibição da lista de produtos
    it('Deve validar a exibição da lista de produtos', () => {
      // Verificação: A lista de produtos deve ser visível e ter itens
      cy.contains('Products').should('be.visible');
      cy.get('.inventory_item').should('have.length.greaterThan', 0); // Verifica se há pelo menos um item
    });
  
// Teste para visualizar detalhes de um produto
it('Deve visualizar os detalhes de um produto específico', () => {
    // Ação: Clicar no nome de um produto
    cy.get('.inventory_item_name').contains('Sauce Labs Backpack').click();

    // Verificação: Deve estar na página de detalhes do produto e ver seu nome
    cy.url().should('include', '/inventory-item.html?id=4'); // ID específico do Sauce Labs Backpack
    cy.get('.inventory_details_name').should('contain', 'Sauce Labs Backpack');
    cy.get('.inventory_details_desc').should('be.visible');
    cy.get('.inventory_details_price').should('be.visible');

    // Ação: Clicar para voltar à lista de produtos
    // Adiciona uma espera para garantir que o elemento está visível antes de clicar
    cy.contains('BACK TO PRODUCTS', { matchCase: false }).should('be.visible').click();

    // Verificação: Deve voltar para a página de inventário
    cy.url().should('include', '/inventory.html');
  });


  
    // Teste para ordenar produtos por nome (A a Z)
    it('Deve ordenar os produtos por nome de A a Z', () => {
      // Ação: Selecionar a opção de ordenação
      cy.get('.product_sort_container').select('az');
      // Verificação: O primeiro item deve ser 'Sauce Labs Backpack'
      cy.get('.inventory_item_name').first().should('contain', 'Sauce Labs Backpack');
      // Verificação: O último item deve ser 'Test.allTheThings() T-Shirt (Red)'
      cy.get('.inventory_item_name').last().should('contain', 'Test.allTheThings() T-Shirt (Red)');
    });
  
    // Teste para ordenar produtos por nome (Z a A)
    it('Deve ordenar os produtos por nome de Z a A', () => {
      // Ação: Selecionar a opção de ordenação
      cy.get('.product_sort_container').select('za');
      // Verificação: O primeiro item deve ser 'Test.allTheThings() T-Shirt (Red)'
      cy.get('.inventory_item_name').first().should('contain', 'Test.allTheThings() T-Shirt (Red)');
      // Verificação: O último item deve ser 'Sauce Labs Backpack'
      cy.get('.inventory_item_name').last().should('contain', 'Sauce Labs Backpack');
    });
  
    // Teste para ordenar produtos por preço (menor para maior)
    it('Deve ordenar os produtos por preço do menor para o maior', () => {
      // Ação: Selecionar a opção de ordenação
      cy.get('.product_sort_container').select('lohi');
      // Verificação: O primeiro item deve ter o preço mais baixo
      cy.get('.inventory_item_price').first().should('contain', '7.99');
      // Verificação: O último item deve ter o preço mais alto
      cy.get('.inventory_item_price').last().should('contain', '49.99');
    });
  
    // Teste para ordenar produtos por preço (maior para menor)
    it('Deve ordenar os produtos por preço do maior para o menor', () => {
      // Ação: Selecionar a opção de ordenação
      cy.get('.product_sort_container').select('hilo');
      // Verificação: O primeiro item deve ter o preço mais alto
      cy.get('.inventory_item_price').first().should('contain', '49.99');
      // Verificação: O último item deve ter o preço mais baixo
      cy.get('.inventory_item_price').last().should('contain', '7.99');
    });
  
  });