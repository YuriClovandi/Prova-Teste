// Testes para a funcionalidade do Carrinho
describe('Funcionalidade do Carrinho do Sauce Demo', () => {

    // Antes de cada teste, faz o login para acessar a página de produtos
    beforeEach(() => {
      cy.visit('https://www.saucedemo.com/')
      cy.get('#user-name').type('standard_user');
      cy.get('#password').type('secret_sauce');
      cy.get('#login-button').click();
      cy.url().should('include', '/inventory.html');
    });
  
    // Teste para adicionar e validar produtos no carrinho
    it('Deve adicionar produtos ao carrinho e validar os itens', () => {
      // Ação: Adicionar dois produtos ao carrinho
      cy.get('.btn_primary').contains('Add to cart').first().click(); // Adiciona o primeiro produto
      cy.get('.shopping_cart_badge').should('contain', '1'); // Verifica que o badge mostra 1
      cy.get('.btn_primary').contains('Add to cart').eq(1).click(); // Adiciona o segundo produto
      cy.get('.shopping_cart_badge').should('contain', '2'); // Verifica que o badge mostra 2
  
      // Ação: Ir para a página do carrinho
      cy.get('.shopping_cart_link').click();
      cy.url().should('include', '/cart.html');
  
      // Verificação: Validar que os itens adicionados estão corretos
      cy.get('.cart_list').children().should('have.length', 3); // A lista inclui o cabeçalho + 2 itens
      cy.get('.inventory_item_name').first().should('contain', 'Sauce Labs Backpack');
      cy.get('.inventory_item_name').last().should('contain', 'Sauce Labs Bike Light');
    });
  
    // Teste para remover produtos do carrinho
    it('Deve remover produtos do carrinho', () => {
      // Ação: Adicionar um produto
      cy.get('.btn_primary').contains('Add to cart').first().click();
      cy.get('.shopping_cart_badge').should('contain', '1');
  
      // Ação: Ir para a página do carrinho
      cy.get('.shopping_cart_link').click();
      cy.url().should('include', '/cart.html');
  
      // Ação: Remover o produto
      cy.get('.btn_secondary').contains('Remove').click();
  
      // Verificação: O carrinho deve estar vazio (badge não existe mais, e lista com apenas o cabeçalho)
      cy.get('.cart_list').children().should('have.length', 2); // Cabeçalho + item removido (agora não presente)
      cy.get('.shopping_cart_badge').should('not.exist');
    });
  
  });